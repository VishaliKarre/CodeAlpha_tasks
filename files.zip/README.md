# CodeAlpha_SecureCodeReview

**CodeAlpha Cybersecurity Internship — Task 3: Secure Coding Review Tool**

A Python-based static code analysis tool that audits Python source files for common security vulnerabilities. Generates both terminal output and a professional HTML report with findings, descriptions, and remediation steps.

---

## Features

- **22 vulnerability rules** across 8 security categories
- Detects SQL Injection, Command Injection, Code Injection, Hardcoded Secrets, Weak Cryptography, Insecure Deserialization, Path Traversal, and Misconfigurations
- Severity ratings: CRITICAL / HIGH / MEDIUM / LOW / INFO
- CWE (Common Weakness Enumeration) references for every finding
- Colour-coded terminal output
- HTML report generation
- Scan a single file or an entire project directory
- BPF-style severity filter

---

## Requirements

```bash
pip install colorama
```

---

## Usage

```bash
# Scan a single file
python3 secure_code_review.py target.py

# Scan an entire project directory
python3 secure_code_review.py ./my_project/

# Save an HTML report
python3 secure_code_review.py target.py --report report.html

# Filter by severity
python3 secure_code_review.py target.py --severity HIGH

# Combine options
python3 secure_code_review.py ./project/ --severity CRITICAL --report critical.html
```

---

## Vulnerability Rules Covered

| ID     | Vulnerability                        | Severity | CWE      |
|--------|--------------------------------------|----------|----------|
| SEC001 | SQL Injection (f-string)             | CRITICAL | CWE-89   |
| SEC002 | SQL Injection (% formatting)         | CRITICAL | CWE-89   |
| SEC003 | Command Injection — os.system()      | CRITICAL | CWE-78   |
| SEC004 | Command Injection — shell=True       | HIGH     | CWE-78   |
| SEC005 | Command Injection — os.popen()       | HIGH     | CWE-78   |
| SEC006 | Code Injection — eval()              | CRITICAL | CWE-95   |
| SEC007 | Code Injection — exec()              | CRITICAL | CWE-95   |
| SEC008 | Code Injection — compile()           | HIGH     | CWE-95   |
| SEC009 | Hardcoded Password                   | HIGH     | CWE-798  |
| SEC010 | Hardcoded API Key / Secret           | HIGH     | CWE-798  |
| SEC011 | Hardcoded Private Key                | CRITICAL | CWE-321  |
| SEC012 | Weak Hash — MD5                      | MEDIUM   | CWE-327  |
| SEC013 | Weak Hash — SHA1                     | MEDIUM   | CWE-327  |
| SEC014 | Insecure Random (random module)      | MEDIUM   | CWE-338  |
| SEC015 | Insecure Deserialization — pickle    | CRITICAL | CWE-502  |
| SEC016 | Insecure Deserialization — yaml.load | HIGH     | CWE-502  |
| SEC017 | Path Traversal Risk                  | HIGH     | CWE-22   |
| SEC018 | Flask Debug Mode Enabled             | HIGH     | CWE-94   |
| SEC019 | Assert Used for Security Check       | MEDIUM   | CWE-617  |
| SEC020 | SSL Verification Disabled            | HIGH     | CWE-295  |
| SEC021 | Broad Exception Suppression          | LOW      | CWE-390  |
| SEC022 | Sensitive Data in Logs               | MEDIUM   | CWE-532  |

---

## Demo

A sample vulnerable Python file (`vulnerable_app.py`) is included for demonstration. Run:

```bash
python3 secure_code_review.py vulnerable_app.py --report demo_report.html
```

This will detect ~14 vulnerabilities across multiple categories and generate an HTML report.

---

## Project Structure

```
CodeAlpha_SecureCodeReview/
├── secure_code_review.py   # Main scanner tool
├── vulnerable_app.py       # Sample vulnerable app (demo only)
└── README.md               # Project documentation
```

---

## How It Works

1. Loads 22 pre-defined vulnerability rules with regex patterns
2. Reads source files line by line, skipping comments
3. Matches each line against all rules
4. Collects findings with file path, line number, and code snippet
5. Sorts findings by severity and generates terminal + HTML reports

---

**CodeAlpha Cybersecurity Internship** | [codealpha.tech](https://www.codealpha.tech)

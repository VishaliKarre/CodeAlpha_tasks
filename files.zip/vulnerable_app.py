#!/usr/bin/env python3
"""
vulnerable_app.py — Sample Vulnerable Python Application
---------------------------------------------------------
This file is intentionally written with common security
vulnerabilities to demonstrate the Secure Code Review Tool.

DO NOT deploy this code. It is for educational purposes only.
"""

import os
import pickle
import random
import hashlib
import sqlite3
import subprocess
import yaml
import logging

# ── Hardcoded secrets (SEC009, SEC010) ────────────────────────────────────────
password     = "SuperSecret123"
api_key      = "sk-abcdef1234567890abcdef"
secret_key   = "my_flask_secret_key_hardcoded"

# ── Weak hashing (SEC012, SEC013) ─────────────────────────────────────────────
def hash_password(pwd):
    return hashlib.md5(pwd.encode()).hexdigest()   # MD5 — broken

def legacy_hash(data):
    return hashlib.sha1(data.encode()).hexdigest() # SHA1 — deprecated

# ── Insecure random (SEC014) ──────────────────────────────────────────────────
def generate_token():
    return str(random.randint(100000, 999999))     # not cryptographically secure

# ── SQL Injection (SEC001) ────────────────────────────────────────────────────
def get_user(username):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)                          # direct f-string — injectable
    return cursor.fetchone()

# ── Command Injection (SEC003, SEC004) ────────────────────────────────────────
def ping_host(host):
    os.system(f"ping -c 4 {host}")                # os.system — injectable

def list_files(path):
    subprocess.run(f"ls {path}", shell=True)       # shell=True — injectable

# ── eval / exec (SEC006, SEC007) ─────────────────────────────────────────────
def calculate(expression):
    return eval(expression)                        # arbitrary code execution

def run_code(code_str):
    exec(code_str)                                 # arbitrary code execution

# ── Insecure deserialization (SEC015) ─────────────────────────────────────────
def load_session(data):
    return pickle.loads(data)                      # RCE via crafted pickle data

# ── Insecure YAML load (SEC016) ───────────────────────────────────────────────
def load_config(yaml_str):
    return yaml.load(yaml_str)                     # should be yaml.safe_load()

# ── Sensitive data in logs (SEC022) ──────────────────────────────────────────
def authenticate(user, password):
    logging.info(f"Login attempt: user={user}, password={password}")  # logs password!
    return user == "admin" and password == "admin"

# ── SSL verification disabled (SEC020) ───────────────────────────────────────
def fetch_data(url):
    import requests
    return requests.get(url, verify=False)         # MITM vulnerable

# ── Assert for security check (SEC019) ───────────────────────────────────────
def delete_user(requesting_user, target_id):
    assert requesting_user.role == "admin", "Access denied"
    # assert is stripped with python -O — bypasses access control!
    db_delete(target_id)

def db_delete(target_id):
    pass

# ── Broad exception suppression (SEC021) ─────────────────────────────────────
def read_config(path):
    try:
        with open(path) as f:
            return f.read()
    except:                                        # silently swallows all errors
        pass

# ── Flask debug mode (SEC018) ─────────────────────────────────────────────────
# from flask import Flask
# app = Flask(__name__)
# app.run(debug=True)  # exposes interactive debugger in browser

if __name__ == "__main__":
    print("Vulnerable app — for demonstration only.")

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════╗
║       CodeAlpha — Cybersecurity Internship           ║
║       Task 3: Secure Coding Review Tool              ║
║       Author : <Your Name>                           ║
║       Language: Python 3                             ║
╚══════════════════════════════════════════════════════╝

Description:
    A static code analysis tool that scans Python source files
    for common security vulnerabilities including:
      - SQL Injection
      - Command Injection
      - Hardcoded credentials / secrets
      - Insecure use of eval() / exec()
      - Weak cryptography (MD5, SHA1)
      - Insecure deserialization (pickle)
      - Insecure random number generation
      - Path traversal vulnerabilities
      - Debug mode left enabled
      - Missing input validation patterns

Usage:
    python3 secure_code_review.py <file_or_directory>
    python3 secure_code_review.py target.py
    python3 secure_code_review.py ./my_project/
    python3 secure_code_review.py target.py --report report.html
    python3 secure_code_review.py target.py --severity HIGH

Requirements:
    pip install colorama
    (No other external dependencies — uses only stdlib + colorama)
"""

import re
import os
import sys
import argparse
import datetime
from pathlib import Path
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Optional

# ── Colour support ────────────────────────────────────────────────────────────
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    RED    = Fore.RED
    YELLOW = Fore.YELLOW
    GREEN  = Fore.GREEN
    CYAN   = Fore.CYAN
    BLUE   = Fore.BLUE
    GREY   = Fore.WHITE + Style.DIM
    BOLD   = Style.BRIGHT
    RESET  = Style.RESET_ALL
except ImportError:
    RED = YELLOW = GREEN = CYAN = BLUE = GREY = BOLD = RESET = ""


# ═════════════════════════════════════════════════════════════════════════════
#  Vulnerability rule definitions
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class Rule:
    id: str
    name: str
    severity: str          # CRITICAL / HIGH / MEDIUM / LOW / INFO
    category: str
    pattern: str           # regex pattern
    description: str
    recommendation: str
    cwe: str               # CWE reference


RULES: List[Rule] = [

    # ── SQL Injection ─────────────────────────────────────────────────────────
    Rule(
        id="SEC001",
        name="SQL Injection — String Formatting",
        severity="CRITICAL",
        category="Injection",
        pattern=r'(execute|cursor\.execute|db\.execute)\s*\(\s*[f"\'](.*?)(SELECT|INSERT|UPDATE|DELETE|DROP)',
        description="SQL query constructed using string formatting or f-strings. User input may be injected directly into the query.",
        recommendation="Use parameterised queries with placeholders: cursor.execute('SELECT * FROM users WHERE id=?', (user_id,))",
        cwe="CWE-89"
    ),
    Rule(
        id="SEC002",
        name="SQL Injection — % Formatting",
        severity="CRITICAL",
        category="Injection",
        pattern=r'(execute|cursor\.execute)\s*\(.*?%\s*(\(|[a-zA-Z_])',
        description="SQL query built using % string formatting. Vulnerable to SQL injection if variables contain user-supplied data.",
        recommendation="Replace % formatting with parameterised queries.",
        cwe="CWE-89"
    ),

    # ── Command Injection ─────────────────────────────────────────────────────
    Rule(
        id="SEC003",
        name="Command Injection — os.system()",
        severity="CRITICAL",
        category="Injection",
        pattern=r'os\.system\s*\(',
        description="os.system() executes shell commands. If user input is passed, an attacker can inject arbitrary OS commands.",
        recommendation="Use subprocess.run() with a list of arguments (shell=False) and never pass user input directly.",
        cwe="CWE-78"
    ),
    Rule(
        id="SEC004",
        name="Command Injection — subprocess shell=True",
        severity="HIGH",
        category="Injection",
        pattern=r'subprocess\.(run|call|Popen|check_output)\s*\(.*shell\s*=\s*True',
        description="subprocess called with shell=True. This passes the command to the shell, enabling injection if user input is involved.",
        recommendation="Set shell=False and pass command as a list: subprocess.run(['ls', '-la'])",
        cwe="CWE-78"
    ),
    Rule(
        id="SEC005",
        name="Command Injection — os.popen()",
        severity="HIGH",
        category="Injection",
        pattern=r'os\.popen\s*\(',
        description="os.popen() is deprecated and vulnerable to command injection if user input is concatenated into the command string.",
        recommendation="Use subprocess.run() with shell=False and a list of arguments.",
        cwe="CWE-78"
    ),

    # ── Dangerous Functions ───────────────────────────────────────────────────
    Rule(
        id="SEC006",
        name="Code Injection — eval()",
        severity="CRITICAL",
        category="Code Injection",
        pattern=r'\beval\s*\(',
        description="eval() executes arbitrary Python code. If user-controlled data is passed, full remote code execution is possible.",
        recommendation="Avoid eval() entirely. Use ast.literal_eval() for safe expression evaluation of literals only.",
        cwe="CWE-95"
    ),
    Rule(
        id="SEC007",
        name="Code Injection — exec()",
        severity="CRITICAL",
        category="Code Injection",
        pattern=r'\bexec\s*\(',
        description="exec() executes arbitrary Python code at runtime. Passing user input enables full code execution by attackers.",
        recommendation="Avoid exec(). Restructure logic to avoid dynamic code execution entirely.",
        cwe="CWE-95"
    ),
    Rule(
        id="SEC008",
        name="Code Injection — compile()",
        severity="HIGH",
        category="Code Injection",
        pattern=r'\bcompile\s*\(',
        description="compile() can generate executable code objects. Combined with exec/eval it enables code injection.",
        recommendation="Avoid compile() with user-supplied strings. Validate and sanitise all inputs.",
        cwe="CWE-95"
    ),

    # ── Hardcoded Secrets ─────────────────────────────────────────────────────
    Rule(
        id="SEC009",
        name="Hardcoded Password",
        severity="HIGH",
        category="Secrets",
        pattern=r'(password|passwd|pwd)\s*=\s*["\'][^"\']{4,}["\']',
        description="A password appears to be hardcoded as a string literal. Hardcoded credentials are trivially extracted from source code.",
        recommendation="Store credentials in environment variables or a secrets manager. Use os.environ.get('DB_PASSWORD').",
        cwe="CWE-798"
    ),
    Rule(
        id="SEC010",
        name="Hardcoded API Key / Secret",
        severity="HIGH",
        category="Secrets",
        pattern=r'(api_key|secret_key|api_secret|access_token|auth_token)\s*=\s*["\'][^"\']{8,}["\']',
        description="An API key or secret token appears hardcoded. This can be extracted from source code or version control history.",
        recommendation="Use environment variables: api_key = os.environ.get('API_KEY'). Add secrets to .gitignore.",
        cwe="CWE-798"
    ),
    Rule(
        id="SEC011",
        name="Hardcoded Private Key / Certificate",
        severity="CRITICAL",
        category="Secrets",
        pattern=r'-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----',
        description="A private key is embedded directly in source code. This completely compromises any system secured by this key.",
        recommendation="Never commit private keys to source control. Use key files referenced by path, stored outside the codebase.",
        cwe="CWE-321"
    ),

    # ── Weak Cryptography ─────────────────────────────────────────────────────
    Rule(
        id="SEC012",
        name="Weak Hash — MD5",
        severity="MEDIUM",
        category="Cryptography",
        pattern=r'hashlib\.md5\s*\(',
        description="MD5 is a cryptographically broken hash function. Collisions can be generated in seconds on modern hardware.",
        recommendation="Use hashlib.sha256() or hashlib.sha3_256() for general hashing. For passwords, use bcrypt or argon2.",
        cwe="CWE-327"
    ),
    Rule(
        id="SEC013",
        name="Weak Hash — SHA1",
        severity="MEDIUM",
        category="Cryptography",
        pattern=r'hashlib\.sha1\s*\(',
        description="SHA-1 is deprecated and vulnerable to collision attacks. Not suitable for security-sensitive operations.",
        recommendation="Use hashlib.sha256() or stronger. For passwords use bcrypt, scrypt, or argon2.",
        cwe="CWE-327"
    ),
    Rule(
        id="SEC014",
        name="Insecure Random — random module",
        severity="MEDIUM",
        category="Cryptography",
        pattern=r'\brandom\.(random|randint|randrange|choice|shuffle)\s*\(',
        description="The random module uses a pseudo-random generator (Mersenne Twister) that is NOT cryptographically secure.",
        recommendation="Use secrets.token_hex(), secrets.randbelow(), or os.urandom() for security-sensitive randomness.",
        cwe="CWE-338"
    ),

    # ── Insecure Deserialization ──────────────────────────────────────────────
    Rule(
        id="SEC015",
        name="Insecure Deserialization — pickle.loads()",
        severity="CRITICAL",
        category="Deserialization",
        pattern=r'pickle\.(loads|load)\s*\(',
        description="pickle.loads() executes arbitrary Python code embedded in serialised data. Deserialising untrusted data enables RCE.",
        recommendation="Never deserialise untrusted data with pickle. Use JSON or a safe schema-validated format instead.",
        cwe="CWE-502"
    ),
    Rule(
        id="SEC016",
        name="Insecure Deserialization — yaml.load()",
        severity="HIGH",
        category="Deserialization",
        pattern=r'yaml\.load\s*\([^,)]+\)',
        description="yaml.load() without a safe Loader can execute arbitrary Python objects embedded in YAML input.",
        recommendation="Use yaml.safe_load() instead of yaml.load(), or explicitly pass Loader=yaml.SafeLoader.",
        cwe="CWE-502"
    ),

    # ── Path Traversal ────────────────────────────────────────────────────────
    Rule(
        id="SEC017",
        name="Path Traversal Risk",
        severity="HIGH",
        category="Path Traversal",
        pattern=r'open\s*\(\s*[^"\'()\s]*\+',
        description="A file is opened using a path built by string concatenation. User input may include '../' sequences to traverse the filesystem.",
        recommendation="Validate and sanitise file paths. Use os.path.abspath() and check the result starts with your intended base directory.",
        cwe="CWE-22"
    ),

    # ── Debug / Misconfiguration ──────────────────────────────────────────────
    Rule(
        id="SEC018",
        name="Debug Mode Enabled — Flask",
        severity="HIGH",
        category="Misconfiguration",
        pattern=r'app\.run\s*\(.*debug\s*=\s*True',
        description="Flask debug mode is enabled. This exposes an interactive debugger in the browser that allows arbitrary code execution.",
        recommendation="Set debug=False in production. Use environment variables: debug=os.environ.get('DEBUG', False).",
        cwe="CWE-94"
    ),
    Rule(
        id="SEC019",
        name="Assert Used for Security Check",
        severity="MEDIUM",
        category="Logic Flaw",
        pattern=r'\bassert\b.*(auth|permission|admin|role|login|access)',
        description="assert statements are removed when Python runs with the -O (optimise) flag, silently bypassing security checks.",
        recommendation="Replace assert with explicit if/raise statements for all security-critical checks.",
        cwe="CWE-617"
    ),
    Rule(
        id="SEC020",
        name="Insecure SSL Verification Disabled",
        severity="HIGH",
        category="Misconfiguration",
        pattern=r'verify\s*=\s*False',
        description="SSL certificate verification is disabled. This makes the connection vulnerable to man-in-the-middle attacks.",
        recommendation="Never set verify=False in production. If using a self-signed cert, pass the CA bundle path: verify='/path/to/ca.pem'.",
        cwe="CWE-295"
    ),
    Rule(
        id="SEC021",
        name="Broad Exception Suppression",
        severity="LOW",
        category="Error Handling",
        pattern=r'except\s*:\s*$|except\s+Exception\s*:\s*$',
        description="Catching all exceptions silently can mask security-relevant errors and make debugging extremely difficult.",
        recommendation="Catch specific exceptions. Log errors appropriately. Never silently swallow exceptions.",
        cwe="CWE-390"
    ),
    Rule(
        id="SEC022",
        name="Sensitive Data in Logs",
        severity="MEDIUM",
        category="Information Disclosure",
        pattern=r'(logging|logger|log)\.(info|debug|warning|error)\s*\(.*?(password|token|secret|key|credential)',
        description="Sensitive data such as passwords or tokens may be written to log files, exposing them to log readers.",
        recommendation="Never log sensitive values. Log only non-sensitive identifiers and sanitise all log output.",
        cwe="CWE-532"
    ),
]


# ═════════════════════════════════════════════════════════════════════════════
#  Finding data class
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class Finding:
    rule: Rule
    file_path: str
    line_number: int
    line_content: str


# ═════════════════════════════════════════════════════════════════════════════
#  Scanner
# ═════════════════════════════════════════════════════════════════════════════

class SecureCodeScanner:
    def __init__(self, severity_filter: Optional[str] = None):
        self.findings: List[Finding] = []
        self.files_scanned = 0
        self.lines_scanned = 0
        self.severity_filter = severity_filter
        self._compile_rules()

    def _compile_rules(self):
        """Pre-compile regex patterns for performance."""
        self._compiled = []
        for rule in RULES:
            try:
                self._compiled.append((rule, re.compile(rule.pattern, re.IGNORECASE)))
            except re.error as e:
                print(f"[WARN] Invalid pattern in rule {rule.id}: {e}")

    def scan_file(self, file_path: str):
        """Scan a single Python file for vulnerabilities."""
        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except (IOError, OSError) as e:
            print(f"{YELLOW}[WARN] Cannot read {file_path}: {e}{RESET}")
            return

        self.files_scanned += 1
        self.lines_scanned += len(lines)

        for line_no, line in enumerate(lines, start=1):
            stripped = line.strip()
            # Skip comment lines
            if stripped.startswith("#"):
                continue
            for rule, pattern in self._compiled:
                if pattern.search(line):
                    if self.severity_filter and rule.severity != self.severity_filter:
                        continue
                    self.findings.append(Finding(
                        rule=rule,
                        file_path=file_path,
                        line_number=line_no,
                        line_content=line.rstrip()
                    ))

    def scan_directory(self, dir_path: str):
        """Recursively scan all .py files in a directory."""
        for root, _, files in os.walk(dir_path):
            for fname in files:
                if fname.endswith(".py"):
                    self.scan_file(os.path.join(root, fname))

    def scan(self, target: str):
        """Auto-detect file or directory and scan."""
        if os.path.isfile(target):
            self.scan_file(target)
        elif os.path.isdir(target):
            self.scan_directory(target)
        else:
            print(f"{RED}[ERROR] Target not found: {target}{RESET}")
            sys.exit(1)


# ═════════════════════════════════════════════════════════════════════════════
#  Reporter
# ═════════════════════════════════════════════════════════════════════════════

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
SEVERITY_COLOUR = {
    "CRITICAL": RED + BOLD,
    "HIGH":     RED,
    "MEDIUM":   YELLOW,
    "LOW":      CYAN,
    "INFO":     GREY,
}


class Reporter:
    def __init__(self, scanner: SecureCodeScanner):
        self.scanner = scanner

    # ── Terminal report ───────────────────────────────────────────────────────
    def print_terminal(self):
        findings = sorted(
            self.scanner.findings,
            key=lambda f: SEVERITY_ORDER.get(f.rule.severity, 9)
        )

        print(f"\n{CYAN}{BOLD}{'═'*66}{RESET}")
        print(f"{CYAN}{BOLD}  CodeAlpha — Secure Code Review Report{RESET}")
        print(f"{CYAN}{BOLD}{'═'*66}{RESET}")
        print(f"  Scanned   : {self.scanner.files_scanned} file(s), {self.scanner.lines_scanned} lines")
        print(f"  Findings  : {len(findings)}")
        print(f"  Generated : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{CYAN}{'─'*66}{RESET}")

        if not findings:
            print(f"\n  {GREEN}{BOLD}No vulnerabilities detected!{RESET}\n")
            return

        # Summary counts
        counts = defaultdict(int)
        for f in findings:
            counts[f.rule.severity] += 1
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            if counts[sev]:
                col = SEVERITY_COLOUR[sev]
                print(f"  {col}{sev:<10}{RESET} {counts[sev]}")
        print(f"{CYAN}{'─'*66}{RESET}")

        # Individual findings
        for i, finding in enumerate(findings, 1):
            sev_col = SEVERITY_COLOUR.get(finding.rule.severity, "")
            print(f"\n  {BOLD}[{i}] {finding.rule.name}{RESET}")
            print(f"  {sev_col}Severity : {finding.rule.severity}{RESET}  │  "
                  f"Category: {finding.rule.category}  │  {finding.rule.cwe}")
            print(f"  File     : {finding.file_path}  Line {finding.line_number}")
            print(f"  Code     : {GREY}{finding.line_content.strip()}{RESET}")
            print(f"  Problem  : {finding.rule.description}")
            print(f"  Fix      : {GREEN}{finding.rule.recommendation}{RESET}")

        print(f"\n{CYAN}{'═'*66}{RESET}\n")

    # ── HTML report ───────────────────────────────────────────────────────────
    def save_html(self, output_path: str):
        findings = sorted(
            self.scanner.findings,
            key=lambda f: SEVERITY_ORDER.get(f.rule.severity, 9)
        )
        counts = defaultdict(int)
        for f in findings:
            counts[f.rule.severity] += 1

        sev_colours = {
            "CRITICAL": "#e05252",
            "HIGH":     "#e09c3a",
            "MEDIUM":   "#e0c93a",
            "LOW":      "#4f7cff",
            "INFO":     "#8b909e",
        }

        rows = ""
        for i, f in enumerate(findings, 1):
            col = sev_colours.get(f.rule.severity, "#8b909e")
            rows += f"""
            <tr>
              <td>{i}</td>
              <td><span class="badge" style="background:{col}20;color:{col};border:1px solid {col}40">{f.rule.severity}</span></td>
              <td><strong>{f.rule.name}</strong><br><small>{f.rule.id} · {f.rule.cwe}</small></td>
              <td>{f.rule.category}</td>
              <td>{f.file_path}<br><small>Line {f.line_number}</small></td>
              <td><code>{f.line_content.strip()[:80]}</code></td>
              <td>{f.rule.description}</td>
              <td style="color:#4caf7d">{f.rule.recommendation}</td>
            </tr>"""

        summary_cards = ""
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            col = sev_colours[sev]
            summary_cards += f"""
            <div class="stat-card" style="border-top:3px solid {col}">
              <div class="stat-num" style="color:{col}">{counts[sev]}</div>
              <div class="stat-label">{sev}</div>
            </div>"""

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Secure Code Review Report — CodeAlpha</title>
<style>
  body {{ font-family: 'Segoe UI', sans-serif; background: #0d0f14; color: #e8eaf0; margin: 0; padding: 2rem; }}
  h1 {{ font-size: 1.8rem; margin-bottom: 4px; }}
  .meta {{ color: #8b909e; font-size: 14px; margin-bottom: 2rem; }}
  .summary {{ display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 2rem; }}
  .stat-card {{ background: #13161e; border-radius: 10px; padding: 1rem 1.5rem; min-width: 120px; }}
  .stat-num {{ font-size: 2rem; font-weight: 700; }}
  .stat-label {{ font-size: 12px; color: #8b909e; margin-top: 4px; letter-spacing: .06em; text-transform: uppercase; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  th {{ background: #13161e; padding: 10px 12px; text-align: left; color: #8b909e; font-size: 11px; text-transform: uppercase; letter-spacing: .06em; }}
  td {{ padding: 10px 12px; border-bottom: 1px solid rgba(255,255,255,.06); vertical-align: top; }}
  tr:hover td {{ background: rgba(255,255,255,.03); }}
  .badge {{ display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 600; }}
  code {{ background: #1a1e29; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 12px; word-break: break-all; }}
  small {{ color: #8b909e; }}
  .total {{ font-size: 1.1rem; margin-bottom: .5rem; }}
</style>
</head>
<body>
<h1>🔒 Secure Code Review Report</h1>
<div class="meta">
  CodeAlpha Cybersecurity Internship · Task 3 &nbsp;|&nbsp;
  Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} &nbsp;|&nbsp;
  {self.scanner.files_scanned} file(s) · {self.scanner.lines_scanned} lines scanned
</div>
<div class="total"><strong>{len(findings)}</strong> vulnerabilities found</div>
<div class="summary">{summary_cards}</div>
<table>
  <thead>
    <tr>
      <th>#</th><th>Severity</th><th>Vulnerability</th><th>Category</th>
      <th>Location</th><th>Code</th><th>Description</th><th>Recommendation</th>
    </tr>
  </thead>
  <tbody>{rows}</tbody>
</table>
</body>
</html>"""

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"{GREEN}  HTML report saved: {output_path}{RESET}")


# ═════════════════════════════════════════════════════════════════════════════
#  Entry point
# ═════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="CodeAlpha Task 3 — Secure Code Review Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 secure_code_review.py app.py
  python3 secure_code_review.py ./my_project/
  python3 secure_code_review.py app.py --report report.html
  python3 secure_code_review.py app.py --severity HIGH
        """
    )
    parser.add_argument("target", help="Python file or directory to scan")
    parser.add_argument("--report", metavar="FILE", help="Save HTML report to file")
    parser.add_argument("--severity", choices=["CRITICAL","HIGH","MEDIUM","LOW","INFO"],
                        help="Filter findings by severity level")
    args = parser.parse_args()

    scanner = SecureCodeScanner(severity_filter=args.severity)
    scanner.scan(args.target)

    reporter = Reporter(scanner)
    reporter.print_terminal()

    if args.report:
        reporter.save_html(args.report)


if __name__ == "__main__":
    main()
